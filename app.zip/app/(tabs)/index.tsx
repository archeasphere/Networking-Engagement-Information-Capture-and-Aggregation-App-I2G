import { createDrawerNavigator } from '@react-navigation/drawer';
import { StyleSheet, FlatList, TouchableOpacity, View, TextInput } from 'react-native';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import Checkbox from 'expo-checkbox';
import TagModal from './TagModal';
import LoginScreen from './login';
import SidebarContent from './SidebarContent'; // Import SidebarContent

const Drawer = createDrawerNavigator();

const initialFiles = [
  { id: '1', name: 'Project Docs.pdf', timestamp: new Date('2025-02-19T00:00:00Z').toUTCString(), icon: 'document-text-outline' },
  { id: '2', name: 'Design Mockups.png', timestamp: new Date('2025-02-18T00:00:00Z').toUTCString(), icon: 'image-outline' },
  { id: '3', name: 'App Code.zip', timestamp: new Date('2025-02-15T00:00:00Z').toUTCString(), icon: 'file-tray-outline' },
  { id: '4', name: 'Meeting Notes.txt', timestamp: new Date('2025-02-10T00:00:00Z').toUTCString(), icon: 'document-outline' },
];

function HomeScreen({ navigation }) {
  const [isGridView, setIsGridView] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [files, setFiles] = useState(initialFiles);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [newTagName, setNewTagName] = useState('');

  const filteredFiles = files.filter((file) =>
    file.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleSelection = (id) => {
    setSelectedFiles((prev) =>
      prev.includes(id) ? prev.filter((fileId) => fileId !== id) : [...prev, id]
    );
  };

  const confirmCreateTag = () => {
    if (selectedFiles.length > 0 && newTagName.trim()) {
      const newTag = {
        id: Date.now().toString(),
        name: newTagName,
        timestamp: new Date().toLocaleDateString(),
        icon: 'pricetag-outline',
      };
      setFiles((prevFiles) => [...prevFiles, newTag]);
      setSelectedFiles([]);
      setModalVisible(false);
      setNewTagName('');
    }
  };

  return (
    <ThemedView style={styles.container}>
      <View style={styles.searchBar}>
        <Ionicons name="search-outline" size={20} color="white" />
        <TextInput
          placeholder="Search files..."
          placeholderTextColor="#aaa"
          style={styles.searchInput}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>
      
      <View style={styles.header}>
        <ThemedText type="title">My Files</ThemedText>
        <TouchableOpacity onPress={() => setIsGridView(!isGridView)}>
          <Ionicons name={isGridView ? 'grid-outline' : 'list-outline'} size={24} color="white" />
        </TouchableOpacity>
      </View>

      {selectedFiles.length > 0 && (
        <TouchableOpacity style={styles.TagButton} onPress={() => setModalVisible(true)}>
          <Ionicons name="pricetag-outline" size={20} color="white" />
          <ThemedText> Create Tag</ThemedText>
        </TouchableOpacity>
      )}
      
      <FlatList
        data={filteredFiles}
        key={isGridView ? 'grid' : 'list'}
        numColumns={isGridView ? 2 : 1}
        renderItem={({ item }) => (
          <View style={[isGridView ? styles.gridItem : styles.rowItem]}>
            <Checkbox
              value={selectedFiles.includes(item.id)}
              onValueChange={() => toggleSelection(item.id)}
              color={selectedFiles.includes(item.id) ? '#007AFF' : undefined}
            />
            <Ionicons name={item.icon} size={28} color="#ffcc00" style={styles.fileIcon} />
            <ThemedText numberOfLines={1} ellipsizeMode="tail" style={styles.fileName}>{item.name}</ThemedText>
            {!isGridView && <ThemedText style={styles.timestamp}>{item.timestamp}</ThemedText>}
            {isGridView && <View style={styles.thumbnail} />}
            {isGridView && <ThemedText style={styles.timestamp}>{item.timestamp}</ThemedText>}
            <Ionicons name="ellipsis-vertical" size={20} color="white" style={styles.menuIcon} />
          </View>
        )}
        keyExtractor={(item) => item.id}
      />
      
      <TagModal
        visible={modalVisible}
        TagName={newTagName}
        onChangeTagName={setNewTagName}
        onCancel={() => setModalVisible(false)}
        onConfirm={confirmCreateTag}
      />
    </ThemedView>
  );
}

export default function AppNavigator() {
  return (
    <Drawer.Navigator drawerContent={(props) => <SidebarContent {...props} />}> 
      <Drawer.Screen name="Home" component={HomeScreen} />
    </Drawer.Navigator>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#121212', padding: 16 },
  searchBar: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#1E1E1E', padding: 10, borderRadius: 10, marginBottom: 12 },
  searchInput: { flex: 1, color: 'white', marginLeft: 10 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  TagButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#007AFF', padding: 12, borderRadius: 8, justifyContent: 'center', marginBottom: 12 },
  rowItem: { flexDirection: 'row', alignItems: 'center', padding: 10, backgroundColor: '#1E1E1E', borderRadius: 10, marginBottom: 8 },
  gridItem: { alignItems: 'center', backgroundColor: '#1E1E1E', borderRadius: 10, padding: 16, margin: 8, flexBasis: '48%' },
  fileIcon: { marginHorizontal: 10 },
  fileName: { flex: 1, color: 'white' },
  timestamp: { color: 'gray', fontSize: 12 },
  menuIcon: { marginLeft: 10 },
  thumbnail: { width: 60, height: 60, backgroundColor: '#333', marginTop: 8 },
  sidebar: { flex: 1, backgroundColor: '#1E1E1E', padding: 20 },
});
